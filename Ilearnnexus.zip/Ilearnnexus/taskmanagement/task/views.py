from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from .models import Task
from .Forms import RegisterForm, TaskForm

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            form = RegisterForm()
            return(request, 'task/register.html', {'form' : form})

def login_user(request):
    if request.method =='POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('task_list')
        return render(request, 'task/login.html')

@login_required
def task_list(request):
    tasks =Task.objects.filter(user = request.user)
    return render(request, 'task/index.html', {'task': tasks})

@login_required
def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'task/index.html', {'form' : form})

@login_required
def delete_task(request, task_id):
    task = Task.objects.get(id = task_id, user =request.user)
    task.delete()
    return redirect('task_list')

def logout_user(request):
    logout(request)
    return redirect('login')
        

